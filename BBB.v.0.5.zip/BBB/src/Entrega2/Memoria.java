/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entrega2;
import Entrega3.Data;
import java.util.HashMap;

/**
 *
 * @author JesusDavid
 */
public class Memoria{

    private HashMap<Integer,String> memS;
    private HashMap<Integer,String> memP;
    private HashMap<Integer,String> memD;
    private HashMap<Integer,String> memK;
    
    private static final int igi = 0; // Init Global Int
    private static final int igf = 3000; // Init Global Float
    private static final int igs = 6000; // Init Global String
    private static final int igb = 8000; // Init Global Boolean

    private static final int ili = 9000; // Init Local Int
    private static final int ilf = 12000; // Init Local Float
    private static final int ils = 15000; // Init Local String
    private static final int ilb = 17000; // Init Local Boolean

    private static final int iti = 18000; // Init Temporal Int
    private static final int itf = 21000; // Init Temporal Float
    private static final int its = 24000; // Init Temporal String
    private static final int itb = 26000; // Init Temporal Boolean

    private static final int ici = 27000; // Init Constant Int
    private static final int icf = 30000; // Init Constant Float
    private static final int ics = 33000; // Init Constant String
    private static final int icb = 35000; // Init Constant Boolean

    private static final int fgi = 2999; // Final Global Int
    private static final int fgf = 5999; // Final Global Float
    private static final int fgs = 7999; // Final Global String
    private static final int fgb = 8999; // Final Global Boolean

    private static final int fli = 11999; // Final Local Int
    private static final int flf = 14999; // Final Local Float
    private static final int fls = 16999; // Final Local String
    private static final int flb = 17999; // Final Local Boolean

    private static final int fti = 20999; // Final Global Int
    private static final int ftf = 23999; // Final Global Float
    private static final int fts = 25999; // Final Global String
    private static final int ftb = 26999; // Final Global Boolean

    private static final int fci = 29999; // Final Global Int
    private static final int fcf = 32999; // Final Global Float
    private static final int fcs = 34999; // Final Global String
    private static final int fcb = 35999; // Final Global Boolean

    private int intGlobal = igi;
    private int floatGlobal = igf;
    private int strGlobal = igs;
    private int blnGlobal = igb;
    
    private int intLocal = ili;
    private int floatLocal = ilf;
    private int strLocal = ils;
    private int blnLocal = ilb;
    
    private int intTemporal = iti;
    private int floatTemporal = itf;
    private int strTemporal = its;
    private int blnTemporal = itb;
    
    private int intConstant = ici;
    private int floatConstant = icf;
    private int strConstant = ics;
    private int blnConstant = icb;
    
    public Memoria(){
            memS = new HashMap<>();
            memP = new HashMap<>();
            memD = new HashMap<>();
            memK = new HashMap<>();
    }
    
    public int saveGlobal(Object obj){
        int dir = Data.ERR1;
        if(obj instanceof Integer){
            dir = intGlobal;
            intGlobal++;
        }else if(obj instanceof Double){
            dir = floatGlobal;
            floatGlobal++;
        }else if(obj instanceof Boolean){
            dir = blnGlobal;
            blnGlobal++;
        }else if(obj instanceof String){
            dir = strGlobal;
            blnGlobal++;
        }
        if(dir != -1){
            if(dir > fgi){
                return Data.ERR2;
            }
            // TODO guardar memoria global
        }
        return dir;
    }
    
    public int saveLocal(Object obj){
        int dir = Data.ERR1;
        if(obj instanceof Integer){
            dir = intLocal;
            intLocal++;
        }else if(obj instanceof Double){
            dir = floatLocal;
            floatLocal++;
        }else if(obj instanceof Boolean){
            dir = blnLocal;
            blnLocal++;
        }else if(obj instanceof String){
            dir = strLocal;
            blnLocal++;
        }
        if(dir != -1){
            if(dir > fgi){
                return Data.ERR2;
            }
            // TODO guardar memoria global
        }
        return dir;
    }
    
    public int saveTemporal(Object obj){
        int dir = Data.ERR1;
        if(obj instanceof Integer){
            dir = intTemporal;
            intTemporal++;
        }else if(obj instanceof Double){
            dir = floatTemporal;
            floatTemporal++;
        }else if(obj instanceof Boolean){
            dir = blnTemporal;
            blnTemporal++;
        }else if(obj instanceof String){
            dir = strTemporal;
            blnTemporal++;
        }
        if(dir != -1){
            if(dir > fgi){
                return Data.ERR2;
            }
            // TODO guardar memoria global
        }
        return dir;
    }
    
    public int getGlobalInt(int dir){
        if(dir >= igi && fgi >= dir){
            // Regresar el valor
        }            
        return Data.ERR3;
    }
    
    public float getGlobalFloat(int dir){
        if(dir >= igf && fgf >= dir){
            // Regresar el valor
        }            
        return Data.ERR3;
    }
    
    public String getGlobalString(int dir){
        if(dir >= igs && fgs >= dir){
            // Regresar el valor
        }            
        return Data.ERR3 + "";
    }
    
    public Boolean getGlobalBoolean(int dir){
        if(dir >= igb && fgb >= dir){
            // Regresar el valor
        }
        return null; // promp errors!
    }
 }
