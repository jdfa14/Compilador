package Entrega2;

public class MemoriaVirual {
    Memoria memG;   // Memoria Global
    Memoria memT;   // Memoria Temporal
    Memoria memL;   // Memoria Local
}
