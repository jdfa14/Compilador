package bbb;

public class Compilador {

    public static void main(String[] args) {
    }
    
}
