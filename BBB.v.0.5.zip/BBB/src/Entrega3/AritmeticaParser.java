/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entrega3;

import java.util.Queue;
import java.util.Stack;

public class AritmeticaParser {
    Queue fila;
    Stack poper;
    
    public AritmeticaParser(){
        //fila = new Queue<Integer>();
        poper = new Stack<Integer>();
    }
}
