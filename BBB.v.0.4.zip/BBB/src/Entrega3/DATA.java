package Entrega3;

public class DATA {

    // Operadores
    public static final int ADD = 4;	// Add +
    public static final int SUB = 5;	// Subtract -
    public static final int MUL = 6;	// Multiply *
    public static final int DIV = 7;	// Divide /
    public static final int MOD = 8;	// Modulus %
    public static final int AND = 9;	// And &
    public static final int OOR = 10;	// OR |
    public static final int OLT = 11;	// Less Than <
    public static final int OGT = 12;	// Greater Than >
    public static final int EQT = 13;	// Equal to ==
    public static final int DIF = 14;	// Different <>
    public static final int GOE = 15;	// Greater or Equal >=
    public static final int LOE = 16;	// Less or Equal <=
    public static final int EQS = 17;	// Equals =
}
