package Entrega2;

public class MemoriaVirual {
    
}
